;((wp) => {
  if (!wp || !wp.element) return;

  const { createElement: h, useEffect, useState, useRef } = wp.element;
  const { render } = wp.element;

  // -------- boot options --------
  const PAGE = window.QA_Assist_Global_SETTINGS || {};
  const BOOT = window.QA_Assist_BOOT || {};
  const CONFIG_URL = BOOT.configEndpoint || '/wp-json/quiz-assist/v1/public-config';
  const fabOffset = Number(BOOT.fabOffset) || 86;
  const panelLift  = Number(BOOT.panelLift)  || 70;

  async function fetchPublicConfigWithMerge() {
    const base = {
      apiBase: PAGE.apiBase || '/wp-json/quiz-assist/v1',
      isUserLoggedIn: !!PAGE.isUserLoggedIn,
      currentUserName: PAGE.currentUserName || '',
      restNonce: PAGE.restNonce || '',
      globalActions: Array.isArray(PAGE.globalActions) ? PAGE.globalActions : [],
      calendlyUrl: PAGE.calendlyUrl || '',
      publicHeader: PAGE.publicHeader || '',
      publicToken: PAGE.publicToken || '',
      sessionHeader: PAGE.sessionHeader || '',
      widgetEnabled: (typeof PAGE.widgetEnabled === 'boolean') ? PAGE.widgetEnabled : true,
      pollInterval: PAGE.pollInterval || 2000,
      enableQuickReplies: (typeof PAGE.enableQuickReplies === 'boolean') ? PAGE.enableQuickReplies : true,
    };

    try {
      const res = await fetch(CONFIG_URL, { credentials: 'same-origin', cache: 'no-store' });
      if (!res.ok) throw new Error(res.status);
      const remote = await res.json();
      return {
        ...remote,
        apiBase: base.apiBase,
        isUserLoggedIn: base.isUserLoggedIn,
        currentUserName: base.currentUserName,
        restNonce: base.restNonce,
        sessionHeader: base.sessionHeader,
        pollInterval: base.pollInterval,
        enableQuickReplies: base.enableQuickReplies
      };
    } catch (_) {
      return base;
    }
  }

  // ---------- utils ----------
  const sk = (k) => `qa_gl_${k}`;
  const isValidSid = (s) => typeof s === 'string' && /^\d+$/.test(s) && s !== '0';

  function sanitizeStoredSid() {
    const raw = localStorage.getItem(sk('sid'));
    if (!isValidSid(String(raw || ''))) {
      localStorage.removeItem(sk('sid'));
      return '';
    }
    return String(raw);
  }

  function makeHeaders(extra = {}) {
    const h = Object.assign({ 'Accept': 'application/json' }, extra || {});
    const nonce = (PAGE && PAGE.restNonce) ? PAGE.restNonce : '';
    if (nonce) h['X-WP-Nonce'] = nonce;
    return h;
  }
  function keyFor(m) {
    return m.id ? `id-${m.id}` : (m._tempId ? `t-${m._tempId}` : `k-${(m.created_at || '')}-${(m.message || '').slice(0,16)}`);
  }
  function sameMsgList(a, b) {
    if (!Array.isArray(a) || !Array.isArray(b)) return false;
    if (a.length !== b.length) return false;
    for (let i = 0; i < a.length; i++) {
      const x = a[i], y = b[i];
      if (x.sender !== y.sender) return false;
      if (x.message !== y.message) return false;
      if (x.created_at !== y.created_at) return false;
      if ((x.id ?? null) !== (y.id ?? null)) return false;
    }
    return true;
  }
  const countAdmins = (msgs) => (msgs || []).reduce((n,m)=>n + (m && m.sender==='admin' ? 1 : 0), 0);

  // ---------- icons ----------
  const supportIconUrl = (() => { try { return new URL('../img/support-customer-icon.png', document.currentScript && document.currentScript.src ? document.currentScript.src : window.location.href).toString(); } catch(e){ return 'assets/img/support-customer-icon.png'; } })();
  const sv = (props, d) => h('svg', Object.assign({fill:'currentColor','aria-hidden':'true'}, props), h('path',{d}));
  const IconHome     = () => sv({width:20,height:20,viewBox:'0 0 24 24'}, 'M12 3 3 10h2v10h5v-6h4v6h5V10h2L12 3z');
  const IconChat     = () => h('span',{className:'qa-tab-icon-support','aria-hidden':'true'}, h('img',{src:supportIconUrl, alt:''}));
  const IconClose    = () => h('svg',{width:20,height:20,viewBox:'0 0 24 24','aria-hidden':'true'},
                           h('path',{d:'M6 6l12 12M18 6 6 18', fill:'none', stroke:'currentColor', strokeWidth:2.25, strokeLinecap:'round'}));
  const IconCalendar = () => sv({width:20,height:20,viewBox:'0 0 24 24'}, 'M7 2v3H5a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2V2h-2v3H9V2H7zm0 7h10v9H7V9z');
  const IconChevron  = () => sv({width:18,height:18,viewBox:'0 0 24 24'}, 'M7 10l5 5 5-5');


  // ---------- draggable floating widgets ----------
  function qaClamp(n, min, max) { return Math.max(min, Math.min(max, n)); }
  function qaReadPos(key) {
    try {
      const raw = localStorage.getItem(key);
      if (!raw) return null;
      const p = JSON.parse(raw);
      if (!p || typeof p.x !== 'number' || typeof p.y !== 'number') return null;
      return p;
    } catch (_) { return null; }
  }
  function qaSavePos(key, x, y) {
    try { localStorage.setItem(key, JSON.stringify({ x, y })); } catch (_) {}
  }
  function qaApplyFixedPos(el, key) {
    if (!el) return;
    const p = qaReadPos(key);
    if (!p) return;
    const rect = el.getBoundingClientRect();
    const w = rect.width || el.offsetWidth || 80;
    const hgt = rect.height || el.offsetHeight || 80;
    const x = qaClamp(p.x, 8, Math.max(8, window.innerWidth - w - 8));
    const y = qaClamp(p.y, 8, Math.max(8, window.innerHeight - hgt - 8));
    el.style.setProperty('left', x + 'px', 'important');
    el.style.setProperty('top', y + 'px', 'important');
    el.style.setProperty('right', 'auto', 'important');
    el.style.setProperty('bottom', 'auto', 'important');
  }
  function qaInstallDrag({ targetSelector, handleSelector, key, ignoreInteractive = true, onApply = null }) {
    let installedKey = '__qaDragInstalled_' + key;
    if (window[installedKey]) return;
    window[installedKey] = true;

    let suppressClickUntil = 0;

    function apply() {
      document.querySelectorAll(targetSelector).forEach((el) => {
        qaApplyFixedPos(el, key);
        if (typeof onApply === 'function') onApply(el, key);
      });
    }

    const mo = new MutationObserver(apply);
    try { mo.observe(document.documentElement, { childList: true, subtree: true }); } catch (_) {}
    window.addEventListener('resize', apply, { passive: true });
    setInterval(apply, 800);
    setTimeout(apply, 60);
    setTimeout(apply, 600);

    document.addEventListener('click', function(e) {
      if (Date.now() < suppressClickUntil) {
        const handle = e.target && e.target.closest && e.target.closest(handleSelector);
        if (handle) {
          e.preventDefault();
          e.stopPropagation();
          if (typeof e.stopImmediatePropagation === 'function') e.stopImmediatePropagation();
        }
      }
    }, true);

    document.addEventListener('pointerdown', function(e) {
      if (!e.target || !e.target.closest) return;
      const handle = e.target.closest(handleSelector);
      if (!handle) return;

      if (ignoreInteractive && !handle.matches('.qa-launcher,.qa-fab')) {
        const interactive = e.target.closest('button,a,input,textarea,select,[role="button"]');
        if (interactive && interactive !== handle) return;
      }

      const target = handle.closest(targetSelector) || document.querySelector(targetSelector);
      if (!target) return;

      qaApplyFixedPos(target, key);
      if (typeof onApply === 'function') onApply(target, key);

      const startX = e.clientX;
      const startY = e.clientY;
      const rect = target.getBoundingClientRect();
      const offsetX = startX - rect.left;
      const offsetY = startY - rect.top;
      let moved = false;

      function move(ev) {
        const dx = ev.clientX - startX;
        const dy = ev.clientY - startY;
        if (!moved && Math.hypot(dx, dy) < 5) return;
        moved = true;
        const w = rect.width || target.offsetWidth || 80;
        const h = rect.height || target.offsetHeight || 80;
        const x = qaClamp(ev.clientX - offsetX, 8, Math.max(8, window.innerWidth - w - 8));
        const y = qaClamp(ev.clientY - offsetY, 8, Math.max(8, window.innerHeight - h - 8));
        target.style.setProperty('left', x + 'px', 'important');
        target.style.setProperty('top', y + 'px', 'important');
        target.style.setProperty('right', 'auto', 'important');
        target.style.setProperty('bottom', 'auto', 'important');
        qaSavePos(key, x, y);
        if (typeof onApply === 'function') onApply(target, key);
        ev.preventDefault();
      }

      function up() {
        document.removeEventListener('pointermove', move, true);
        document.removeEventListener('pointerup', up, true);
        document.removeEventListener('pointercancel', up, true);
        if (moved) suppressClickUntil = Date.now() + 350;
      }

      document.addEventListener('pointermove', move, true);
      document.addEventListener('pointerup', up, true);
      document.addEventListener('pointercancel', up, true);
    }, true);
  }



  function qaReadTransformPos(key) {
    try {
      const raw = localStorage.getItem(key);
      if (!raw) return { x: 0, y: 0 };
      const p = JSON.parse(raw);
      return { x: Number(p.x) || 0, y: Number(p.y) || 0 };
    } catch (_) { return { x: 0, y: 0 }; }
  }
  function qaSaveTransformPos(key, x, y) {
    try { localStorage.setItem(key, JSON.stringify({ x, y })); } catch (_) {}
  }
  function qaApplyTransformPos(el, key) {
    if (!el) return;
    const p = qaReadTransformPos(key);
    el.style.setProperty('transform', `translate3d(${p.x}px, ${p.y}px, 0)`, 'important');
    el.style.setProperty('will-change', 'transform', 'important');
  }
  function qaInstallTransformDrag({ targetSelector, handleSelector, key, onApply = null }) {
    const installedKey = '__qaTransformDragInstalled_' + key;
    if (window[installedKey]) return;
    window[installedKey] = true;

    let suppressClickUntil = 0;
    function apply() {
      document.querySelectorAll(targetSelector).forEach((el) => {
        qaApplyTransformPos(el, key);
        if (typeof onApply === 'function') onApply(el, key);
      });
    }
    const mo = new MutationObserver(apply);
    try { mo.observe(document.documentElement, { childList: true, subtree: true }); } catch (_) {}
    window.addEventListener('resize', apply, { passive: true });
    setTimeout(apply, 60);
    setTimeout(apply, 600);

    document.addEventListener('click', function(e) {
      if (Date.now() < suppressClickUntil) {
        const handle = e.target && e.target.closest && e.target.closest(handleSelector);
        if (handle) {
          e.preventDefault();
          e.stopPropagation();
          if (typeof e.stopImmediatePropagation === 'function') e.stopImmediatePropagation();
        }
      }
    }, true);

    document.addEventListener('pointerdown', function(e) {
      if (!e.target || !e.target.closest) return;
      const handle = e.target.closest(handleSelector);
      if (!handle) return;
      const target = handle.closest(targetSelector) || document.querySelector(targetSelector);
      if (!target) return;

      qaApplyTransformPos(target, key);
      const current = qaReadTransformPos(key);
      const startX = e.clientX;
      const startY = e.clientY;
      const startRect = target.getBoundingClientRect();
      let moved = false;

      function move(ev) {
        const dx = ev.clientX - startX;
        const dy = ev.clientY - startY;
        if (!moved && Math.hypot(dx, dy) < 5) return;
        moved = true;
        const w = startRect.width || target.offsetWidth || 80;
        const h = startRect.height || target.offsetHeight || 80;
        const clampedLeft = qaClamp(startRect.left + dx, 8, Math.max(8, window.innerWidth - w - 8));
        const clampedTop = qaClamp(startRect.top + dy, 8, Math.max(8, window.innerHeight - h - 8));
        const nx = current.x + (clampedLeft - startRect.left);
        const ny = current.y + (clampedTop - startRect.top);
        target.style.setProperty('transform', `translate3d(${nx}px, ${ny}px, 0)`, 'important');
        qaSaveTransformPos(key, nx, ny);
        if (typeof onApply === 'function') onApply(target, key);
        ev.preventDefault();
      }
      function up() {
        document.removeEventListener('pointermove', move, true);
        document.removeEventListener('pointerup', up, true);
        document.removeEventListener('pointercancel', up, true);
        if (moved) suppressClickUntil = Date.now() + 350;
      }
      document.addEventListener('pointermove', move, true);
      document.addEventListener('pointerup', up, true);
      document.addEventListener('pointercancel', up, true);
    }, true);
  }


  function qaInstallFixedIconDrag({ targetSelector, handleSelector, key }) {
    const installedKey = '__qaFixedIconDragInstalled_' + key;
    if (window[installedKey]) return;
    window[installedKey] = true;

    let suppressClickUntil = 0;
    let raf = 0;
    let pending = null;

    function read() {
      try {
        const raw = localStorage.getItem(key);
        if (!raw) return null;
        const p = JSON.parse(raw);
        if (!p || typeof p.x !== 'number' || typeof p.y !== 'number') return null;
        return p;
      } catch (_) { return null; }
    }

    function save(x, y) {
      try { localStorage.setItem(key, JSON.stringify({ x, y })); } catch (_) {}
    }

    function applyTo(el, pos) {
      if (!el) return;
      const rect = el.getBoundingClientRect();
      const w = rect.width || el.offsetWidth || 78;
      const h = rect.height || el.offsetHeight || 78;
      const x = qaClamp(pos.x, 8, Math.max(8, window.innerWidth - w - 8));
      const y = qaClamp(pos.y, 8, Math.max(8, window.innerHeight - h - 8));

      el.style.setProperty('position', 'fixed', 'important');
      el.style.setProperty('left', x + 'px', 'important');
      el.style.setProperty('top', y + 'px', 'important');
      el.style.setProperty('right', 'auto', 'important');
      el.style.setProperty('bottom', 'auto', 'important');
      el.style.setProperty('transform', 'none', 'important');
      el.style.setProperty('z-index', '2147483647', 'important');
    }

    function applySaved() {
      const pos = read();
      if (!pos) return;
      document.querySelectorAll(targetSelector).forEach((el) => applyTo(el, pos));
    }

    const mo = new MutationObserver(applySaved);
    try { mo.observe(document.documentElement, { childList: true, subtree: true }); } catch (_) {}
    window.addEventListener('resize', applySaved, { passive: true });
    setTimeout(applySaved, 60);
    setTimeout(applySaved, 600);

    document.addEventListener('click', function(e) {
      if (Date.now() < suppressClickUntil) {
        const handle = e.target && e.target.closest && e.target.closest(handleSelector);
        if (handle) {
          e.preventDefault();
          e.stopPropagation();
          if (typeof e.stopImmediatePropagation === 'function') e.stopImmediatePropagation();
        }
      }
    }, true);

    document.addEventListener('pointerdown', function(e) {
      if (!e.target || !e.target.closest) return;
      const handle = e.target.closest(handleSelector);
      if (!handle) return;
      const target = handle.closest(targetSelector) || handle;
      if (!target) return;

      // Capture the current visual position once. From here on, use fixed left/top only.
      const startRect = target.getBoundingClientRect();
      const startX = e.clientX;
      const startY = e.clientY;
      const pointerOffsetX = startX - startRect.left;
      const pointerOffsetY = startY - startRect.top;
      let moved = false;

      target.style.setProperty('position', 'fixed', 'important');
      target.style.setProperty('left', startRect.left + 'px', 'important');
      target.style.setProperty('top', startRect.top + 'px', 'important');
      target.style.setProperty('right', 'auto', 'important');
      target.style.setProperty('bottom', 'auto', 'important');
      target.style.setProperty('transform', 'none', 'important');
      target.style.setProperty('transition', 'none', 'important');

      try { target.setPointerCapture && target.setPointerCapture(e.pointerId); } catch (_) {}

      function commit() {
        if (!pending) return;
        const { x, y } = pending;
        pending = null;
        applyTo(target, { x, y });
        save(x, y);
        raf = 0;
      }

      function move(ev) {
        const dx = ev.clientX - startX;
        const dy = ev.clientY - startY;
        if (!moved && Math.hypot(dx, dy) < 4) return;
        moved = true;

        const rect = target.getBoundingClientRect();
        const w = rect.width || target.offsetWidth || 78;
        const h = rect.height || target.offsetHeight || 78;
        const x = qaClamp(ev.clientX - pointerOffsetX, 8, Math.max(8, window.innerWidth - w - 8));
        const y = qaClamp(ev.clientY - pointerOffsetY, 8, Math.max(8, window.innerHeight - h - 8));
        pending = { x, y };
        if (!raf) raf = requestAnimationFrame(commit);
        ev.preventDefault();
      }

      function up(ev) {
        document.removeEventListener('pointermove', move, true);
        document.removeEventListener('pointerup', up, true);
        document.removeEventListener('pointercancel', up, true);
        if (raf) { cancelAnimationFrame(raf); raf = 0; commit(); }
        try { target.releasePointerCapture && target.releasePointerCapture(ev.pointerId); } catch (_) {}
        if (moved) suppressClickUntil = Date.now() + 350;
      }

      document.addEventListener('pointermove', move, true);
      document.addEventListener('pointerup', up, true);
      document.addEventListener('pointercancel', up, true);
    }, true);
  }


  // ---------- main ----------
  function GlobalWidget({ cfg }) {
    const {
      apiBase,
      pollInterval,
      isUserLoggedIn,
      globalActions,
      calendlyUrl,
      widgetEnabled,
      enableQuickReplies
    } = cfg || {};

    // open/close + nav
    const [isOpen, setIsOpen] = useState(false);
    const [tab, setTab] = useState('home'); // home | messages | book

    // Smooth, direct drag for the Global Chat icon only.
    // The chat panel stays fixed in its normal position; only the launcher button moves.
    const globalFabDragRef = useRef({ dragged:false, suppressUntil:0 });
    const [globalFabPos, setGlobalFabPos] = useState(() => {
      try {
        const raw = localStorage.getItem('qa_global_icon_pos_smooth');
        if (!raw) return null;
        const p = JSON.parse(raw);
        if (!p || typeof p.x !== 'number' || typeof p.y !== 'number') return null;
        return p;
      } catch (_) { return null; }
    });

    function saveGlobalFabPos(x, y) {
      try { localStorage.setItem('qa_global_icon_pos_smooth', JSON.stringify({ x, y })); } catch (_) {}
    }

    function handleGlobalFabPointerDown(e) {
      if (e.button != null && e.button !== 0) return;

      const el = e.currentTarget;
      if (!el || !el.getBoundingClientRect) return;

      const rect = el.getBoundingClientRect();
      const width = rect.width || el.offsetWidth || 78;
      const height = rect.height || el.offsetHeight || 78;
      const startX = e.clientX;
      const startY = e.clientY;
      const pointerOffsetX = startX - rect.left;
      const pointerOffsetY = startY - rect.top;
      let lastX = rect.left;
      let lastY = rect.top;
      let moved = false;

      // Critical: immediately switch the visible launcher to fixed left/top coordinates.
      // This removes the slow-step bug caused by right/bottom or transform-based movement.
      el.style.setProperty('position', 'fixed', 'important');
      el.style.setProperty('left', rect.left + 'px', 'important');
      el.style.setProperty('top', rect.top + 'px', 'important');
      el.style.setProperty('right', 'auto', 'important');
      el.style.setProperty('bottom', 'auto', 'important');
      el.style.setProperty('transform', 'none', 'important');
      el.style.setProperty('transition', 'none', 'important');
      el.style.setProperty('z-index', '2147483647', 'important');

      try { el.setPointerCapture && el.setPointerCapture(e.pointerId); } catch (_) {}

      function move(ev) {
        const dx = ev.clientX - startX;
        const dy = ev.clientY - startY;
        if (!moved && Math.hypot(dx, dy) < 5) return;
        moved = true;
        globalFabDragRef.current.dragged = true;

        lastX = qaClamp(ev.clientX - pointerOffsetX, 8, Math.max(8, window.innerWidth - width - 8));
        lastY = qaClamp(ev.clientY - pointerOffsetY, 8, Math.max(8, window.innerHeight - height - 8));

        el.style.setProperty('left', lastX + 'px', 'important');
        el.style.setProperty('top', lastY + 'px', 'important');
        el.style.setProperty('right', 'auto', 'important');
        el.style.setProperty('bottom', 'auto', 'important');
        el.style.setProperty('transform', 'none', 'important');
        ev.preventDefault();
      }

      function up(ev) {
        document.removeEventListener('pointermove', move, true);
        document.removeEventListener('pointerup', up, true);
        document.removeEventListener('pointercancel', up, true);
        try { el.releasePointerCapture && el.releasePointerCapture(ev.pointerId); } catch (_) {}

        if (moved) {
          globalFabDragRef.current.suppressUntil = Date.now() + 350;
          saveGlobalFabPos(lastX, lastY);
          setGlobalFabPos({ x:lastX, y:lastY });
        }

        setTimeout(() => { globalFabDragRef.current.dragged = false; }, 0);
      }

      document.addEventListener('pointermove', move, true);
      document.addEventListener('pointerup', up, true);
      document.addEventListener('pointercancel', up, true);
    }

    // Global Chat icon drag is handled directly on the visible .qa-fab button below.
    // Do not use the older document-level drag installer here; it mixed with right/bottom
    // positioning and caused the icon to move in small steps instead of smoothly.


    // session
    const initialSid = sanitizeStoredSid();
    const [sessionId, setSessionId] = useState(initialSid);
    const [started, setStarted] = useState(isValidSid(initialSid));

    // messages
    const [messages, setMessages] = useState([]);
    const [pending, setPending] = useState([]);
    const [isLoadingMsgs, setIsLoadingMsgs] = useState(false);

    // synthetic admin quick-reply bubbles (persist per session until a *new* real admin reply arrives)
    const [synAdminTips, setSynAdminTips] = useState([]);
    useEffect(() => {
      try {
        if (sessionId) {
          const raw = localStorage.getItem(sk(`syn_${sessionId}`));
          setSynAdminTips(raw ? JSON.parse(raw) : []);
        } else {
          setSynAdminTips([]);
        }
      } catch(_) { setSynAdminTips([]); }
    }, [sessionId]);

    // persist / clean storage
    useEffect(() => {
      try {
        if (!sessionId) return;
        if (synAdminTips.length) {
          localStorage.setItem(sk(`syn_${sessionId}`), JSON.stringify(synAdminTips));
        } else {
          localStorage.removeItem(sk(`syn_${sessionId}`));
        }
      } catch(_) {}
    }, [synAdminTips, sessionId]);

    // CLEAR synthetic tips only when a NEW admin message arrives after they were added
    useEffect(() => {
      const currentAdminCount = countAdmins(messages);
      setSynAdminTips(prev => prev.filter(t => {
        const base = (typeof t.adminCountAtCreate === 'number') ? t.adminCountAtCreate : 0;
        return currentAdminCount <= base;
      }));
    }, [messages]);

    // FAQs
    const [faqs, setFaqs] = useState([]);
    const [faqOpen, setFaqOpen] = useState(null);

    // inputs
    const [input, setInput] = useState('');
    const [loadingStart, setLoadingStart] = useState(false);
    const [error, setError] = useState('');

    // guest profile
    const [gName, setGName] = useState('');
    const [gEmail, setGEmail] = useState('');
    const [gPhone, setGPhone] = useState('');
    const [gReason, setGReason] = useState('');
    const lastSentRef = useRef(0);

    // quick replies
    const quickReplies = (enableQuickReplies ? globalActions : [])
      .filter(a => a && a.label && (a.user || a.text))
      .map(a => ({ label: a.label, text: a.user || a.text }));

    const emailOk = (s) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(s || '').trim());
    const phoneOk = (s) => String(s || '').replace(/\D/g, '').length >= 6;

    // ---- helpers for session ----
    function readGuestMeta(){
      try { return JSON.parse(localStorage.getItem(sk('meta')) || '{}'); }
      catch(_) { return {}; }
    }
    async function autoStartNewSession(){
      try {
        const payload = isUserLoggedIn
          ? {}
          : (() => {
              const meta = readGuestMeta();
              const name  = String(meta.name  || '').trim();
              const email = String(meta.email || '').trim();
              const phone = String(meta.phone || '').trim();
              if (!name || !email || !phone) return null;
              return { guest_name:name, guest_email:email, guest_phone:phone };
            })();

        if (!isUserLoggedIn && !payload) return null;

        const r = await fetch(`${apiBase}/chat/start`, {
          method:'POST', credentials:'same-origin',
          headers: makeHeaders({ 'Content-Type':'application/json' }),
          body: JSON.stringify(payload || {})
        });
        if (!r.ok) return null;
        const d = await r.json().catch(()=>null);
        const sid = d && String(d.session_id || '').trim();
        if (!isValidSid(sid)) return null;

        setSessionId(sid);
        setStarted(true);
        localStorage.setItem(sk('sid'), sid);
        setSynAdminTips([]);
        setError('');
        return sid;
      } catch(_) {
        return null;
      }
    }
    function clearToHome(msg){
      localStorage.removeItem(sk('sid'));
      if (sessionId) localStorage.removeItem(sk(`syn_${sessionId}`));
      setSessionId(''); setStarted(false); setSynAdminTips([]);
      setTab('home');
      setError(msg || 'This chat was closed. Please start a new chat.');
    }

    // ---- fetch FAQs once ----
    useEffect(() => {
      if (!isOpen || faqs.length) return;
      fetch(`${apiBase}/chat/faqs`, { credentials:'same-origin', headers: makeHeaders() })
        .then(r => r.ok ? r.json() : Promise.reject(r.status))
        .then(data => setFaqs(Array.isArray(data?.faqs) ? data.faqs : []))
        .catch(()=>{});
    }, [isOpen]);

    // poll for messages
    useEffect(() => {
      let alive = true, timer = null, gotFirst = false;

      async function poll() {
        if (!alive) return;
        if (!isValidSid(sessionId)) { setIsLoadingMsgs(false); return; }
        if (!gotFirst) setIsLoadingMsgs(true);
        try {
          const r = await fetch(`${apiBase}/chat/messages?session_id=${encodeURIComponent(sessionId)}`, {
            credentials:'same-origin', cache:'no-store', headers: makeHeaders()
          });

          // Do NOT auto-create a new session during background polling.
          // If the session is invalid or deleted, clear it and show the Home screen.
          if (r.status === 400) { clearToHome('Your chat session is invalid. Please start a new chat.'); return; }
          if (r.status === 403) { clearToHome('Your session expired. Please start a new chat.'); return; }
          if (r.status === 410) { clearToHome('This chat was closed. Please start a new chat.'); return; }

          if (!r.ok) throw new Error(String(r.status));

          const data = await r.json();
          const msgs = Array.isArray(data?.messages) ? data.messages : (Array.isArray(data) ? data : []);
          if (alive && Array.isArray(msgs) && !sameMsgList(messages, msgs)) {
            setMessages(msgs);
          }
          gotFirst = true;
        } catch (_) {
          // keep trying silently
        } finally {
          if (!alive) return;
          setIsLoadingMsgs(false);
          timer = setTimeout(poll, pollInterval || 2000);
        }
      }

      if (sessionId) poll();
      return () => { alive = false; if (timer) clearTimeout(timer); };
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [sessionId, pollInterval, apiBase]);

    // -------- nav helpers --------
    function goHome(){ setError(''); setTab('home'); }
    function goMessages(){ setError(''); setTab('messages'); }
    function goBooking(){ setError(''); setTab('book'); }

    function restoreMetaIfAny(){
      try {
        const meta = JSON.parse(localStorage.getItem(sk('meta')) || '{}');
        if (!isUserLoggedIn && meta && (meta.name || meta.email || meta.phone)) {
          setGName(meta.name || ''); setGEmail(meta.email || ''); setGPhone(meta.phone || '');
        }
      } catch(_) {}
    }
    useEffect(()=>{ restoreMetaIfAny(); }, []);

    // Primary CTA
    function primaryAction() {
      setError('');
      if (started && isValidSid(sessionId)) { setTab('messages'); return; }
      startChat();
    }

    function startChat() {
      setError('');
      setLoadingStart(true);
      if (!isUserLoggedIn) {
        if (!gName.trim())        { setLoadingStart(false); return setError('Please enter your name.'); }
        if (!emailOk(gEmail))     { setLoadingStart(false); return setError('Please enter a valid email (e.g., name@example.com).'); }
        if (!String(gPhone || '').replace(/\D/g, '').length) { setLoadingStart(false); return setError('Please enter a valid phone number.'); }
        if (!gReason.trim() || gReason.trim().length < 8) { setLoadingStart(false); return setError('Please write a short first message about why you want to speak with Professor Farhat.'); }
      }
      const payload = isUserLoggedIn ? {} : { guest_name:gName.trim(), guest_email:gEmail.trim(), guest_phone:gPhone.trim() };

      fetch(`${apiBase}/chat/start`, {
        method:'POST', credentials:'same-origin',
        headers: makeHeaders({ 'Content-Type':'application/json' }),
        body: JSON.stringify(payload || {})
      })
        .then(async r => { if (!r.ok) { const j = await r.json().catch(()=>({})); throw new Error(j?.message || 'Could not start chat.'); } return r.json(); })
        .then(d => {
          const sid = String(d.session_id || '').trim();
          if (!isValidSid(sid)) throw new Error('Could not start chat.');
          setSessionId(sid); setStarted(true); setTab('messages');
          localStorage.setItem(sk('sid'), sid);
          setError('');
          if (!isUserLoggedIn) {
            localStorage.setItem(sk('meta'), JSON.stringify({ name:gName.trim(), email:gEmail.trim(), phone:gPhone.trim() }));
            try {
              if (gReason && gReason.trim()) {
                const first = gReason.trim();
                setGReason('');
                setTab('messages');
                sendMessageText(first);
              }
            } catch(e) {}
          } else {
            localStorage.removeItem(sk('meta'));
          }
        })
        .catch(e => setError(e.message || 'Could not start chat. Please try again.'))
        .finally(() => setLoadingStart(false));
    }

    function sendMessageText(text){
      const now = Date.now();
      if (now - (lastSentRef.current || 0) < 300) return;
      lastSentRef.current = now;

      const message = (text || input || '').trim(); if (!message) return;
      let sid = localStorage.getItem(sk('sid')) || sessionId;

      // If sid invalid or deleted, create fresh session *now* (on send), not during polling.
      const doWithValidSid = async () => {
        if (!isValidSid(String(sid || ''))) {
          const ns = await autoStartNewSession();
          if (!ns) throw new Error('forbidden');
          sid = ns;
        }
        return sid;
      };

      setError('');
      const temp = { _tempId: `${Date.now()}-${Math.random()}`, sender:'user', message, created_at: new Date().toLocaleTimeString() };
      setPending(prev => [...prev, temp]);
      setInput('');

      const doSend = (sessionToUse) => fetch(`${apiBase}/chat/send`, {
        method:'POST', credentials:'same-origin',
        headers: makeHeaders({ 'Content-Type':'application/json' }),
        body: JSON.stringify({ session_id: sessionToUse, message })
      });

      (async () => {
        const validSid = await doWithValidSid();
        let r = await doSend(validSid);

        // Handle 400/410 by auto-recreate once, then retry (only when user is sending)
        if (r.status === 400 || r.status === 410) {
          const ns = await autoStartNewSession();
          if (!ns) throw new Error('recreate_failed');
          r = await doSend(ns);
        }

        if (!r.ok) throw new Error('send_failed');

        setTimeout(()=>{ setPending(prev => prev.filter(p => p._tempId !== temp._tempId)); }, 350);
      })().catch(err=>{
        setPending(prev => prev.filter(p => p._tempId !== temp._tempId));
        const msg = String(err || '');
        if (msg.includes('forbidden')) setError('Your session expired. Please start a new chat.');
        else if (msg.includes('recreate_failed')) clearToHome('This chat was closed. Please start a new chat.');
        else setError('Message failed. Please try again.');
      });
    }

    // --- Quick Replies behave as admin answers (synthetic, no backend write) ---
    function handleQuickReplyAsAdmin(text){
      if (!text) return;
      setTab('messages');

      const now = Date.now();
      setSynAdminTips(prev => {
        const recent = prev.filter(t => now - (t.time || 0) < 2000 && t.message === text);
        if (recent.length) return prev;
        const tip = {
          _id: `syn-${now}-${Math.random()}`,
          sender:'admin',
          message:text,
          time: now,
          adminCountAtCreate: countAdmins(messages)
        };
        return [...prev, tip];
      });
    }

    // ----- UI pieces -----
    const FaqAccordion = () => (
      faqs && faqs.length ? h('div',{className:'qa-acc'},
        faqs.map((f,idx)=>h('div',{className:'qa-acc-item'+(faqOpen===idx?' open':''), key:`faq-${idx}`},
          h('button',{className:'qa-acc-head', onClick:()=>{ setError(''); setFaqOpen(faqOpen===idx?null:idx); }},
            h('div',{className:'qa-acc-icon'},'?'),
            h('div',{className:'qa-acc-title'}, f.question || ''),
            h('div',{className:'qa-acc-chevron'}, h(IconChevron))
          ),
          (faqOpen===idx) && h('div',{className:'qa-acc-panel', dangerouslySetInnerHTML:{__html: f.answer || ''}})
        ))
      ) : h('div',{className:'qa-note'}, 'No FAQs yet.')
    );

    const StartChatCard = () => {
      const hasSession = isValidSid(sessionId) && started;

      const buttonEl = h('button', {
        className: 'qa-action-go',
        onClick: primaryAction
      }, loadingStart ? 'Starting…' : (hasSession ? 'Go to Chat' : 'Start Chat'));

      if (hasSession) {
        return h('div', {
          style: { display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%' }
        }, h('div', { className: 'qa-card qa-action' }, buttonEl));
      }

      return h('div', null,
        h('div',{className:'qa-card qa-action'},
          h('div',{className:'qa-action-main'},
            h('div',{className:'qa-action-title'}, 'Start a conversation with Professor Farhat'),
            h('div',{className:'qa-action-sub'}, isUserLoggedIn ? 'You are logged in.' : '(Guests must complete the form first)')
          ),
          buttonEl
        ),
        !!error && h('div',{className:'qa-card qa-error', style:{marginTop:'8px'}}, error)
      );
    };

    // Courtesy message for guests (persists until first real admin reply)
    function CourtesyBubble() {
      if (isUserLoggedIn) return null;
      if (!started) return null;
      const adminCount = countAdmins(messages);
      const hasUserMsg  = (messages || []).some(m => m.sender === 'user') || (pending || []).some(m => m.sender === 'user');
      if (adminCount > 0 || !hasUserMsg) return null;

      const msg = 'Thanks! Professor Farhat will reply soon. You can also WhatsApp or call him at +1 (484) 894-1008';
      return h('div',{className:'qa-msg from-admin qa-msg-courtesy'},
        h('div',{className:'qa-msg-text'}, msg)
      );
    }

    const headerTitle = 'Farhat Lectures Chat';
    const combined = messages.concat(pending);

    return h('div', { className:'qa-floating', style:{ right:'20px', bottom: `${fabOffset}px` }},

      h('button',{
        className:'qa-fab',
        style: globalFabPos ? {
          position:'fixed',
          left: globalFabPos.x + 'px',
          top: globalFabPos.y + 'px',
          right:'auto',
          bottom:'auto',
          transform:'none',
          zIndex:2147483647
        } : null,
        onPointerDown: handleGlobalFabPointerDown,
        onClick:(e)=>{
          if (Date.now() < globalFabDragRef.current.suppressUntil || globalFabDragRef.current.dragged) {
            e.preventDefault();
            e.stopPropagation();
            return;
          }
          setIsOpen(o=>{
            const next = !o;
            if (next) setError('');
            return next;
          });
        },
        'aria-label':isOpen?'Close chat':'Open chat'
      }, h(IconChat)),

      isOpen && h('div',{className:'qa-panel', style:{ right:'20px', bottom: `${fabOffset + panelLift}px` }},
        h('div',{className:'qa-header'},
          h('div',{className:'qa-title'},headerTitle),
          h('button',{className:'qa-close',onClick:()=>setIsOpen(false),'aria-label':'Close'},h(IconClose))
        ),

        h('div',{className:'qa-body'},

          tab==='home' && h('div',{className:'qa-home'},

            (!isUserLoggedIn && !started) && h('div',{className:'qa-card qa-guest'},
              h('div',{className:'qa-hint'}, 'Fill this short form to start a chat. We’ll notify Professor Farhat.'),
              h('ol',{className:'qa-steps'},
                h('li',null,'1) Your info'),
                h('li',null,'2) First message'),
                h('li',null,'3) Start chat')
              ),

              h('div',{className:'qa-field'},h('label',{htmlFor:'qa_g_name'},'Full name'),h('input',{id:'qa_g_name',type:'text',value:gName,onChange:e=>{ setError(''); setGName(e.target.value); },placeholder:'Jane Doe',required:true})),
              h('div',{className:'qa-field'},h('label',{htmlFor:'qa_g_email'},'Email'),h('input',{id:'qa_g_email',type:'email',value:gEmail,onChange:e=>{ setError(''); setGEmail(e.target.value); },placeholder:'jane@example.com',required:true})),
              h('div',{className:'qa-field'},h('label',{htmlFor:'qa_g_phone'},'Phone'),h('input',{id:'qa_g_phone',type:'tel',value:gPhone,onChange:e=>{ setError(''); setGPhone(e.target.value); },placeholder:'(555) 555-5555',required:true})),

              h('div',{className:'qa-field'},
                h('label',{htmlFor:'qa_g_reason'},'Your first message'),
                h('textarea',{ id:'qa_g_reason', rows:3, value:gReason,
                  onChange:e=>{ setError(''); setGReason(e.target.value); },
                  placeholder:'Why do you want to speak with Professor Farhat?', required:true })
              )
            ),

            h(StartChatCard),

            h('div',{className:'qa-card'},
              h('div',{className:'qa-section-title'},'Helpful resources'),
              h(FaqAccordion)
            )
          ),

          tab==='messages' && h('div',{className:'qa-chat'},


            (isLoadingMsgs && combined.length === 0) && h('div',{className:'qa-loading'},
              h('div',{className:'qa-spinner'}),
              h('div',{className:'qa-text'},'Loading chat… Please wait until the conversation is fully loaded.')
            ),

            h('div',{className:'qa-chat-messages'},
              combined.map((m)=>h('div',{key:keyFor(m),className:'qa-msg '+(m.sender==='user'?'from-user':'from-admin'),title:m.sender==='user'?'You':''},
                h('div',{className:'qa-msg-text'},m.message),
                h('div',{className:'qa-msg-time'},m.created_at),
                m._tempId ? h('div',{className:'qa-msg-sending'},'Sending…') : null
              )),
              synAdminTips.map(t => h('div',{key:t._id,className:'qa-msg from-admin'},
                h('div',{className:'qa-msg-text'},t.message)
              )),
              h(CourtesyBubble)
            ),

            ((isUserLoggedIn||started) && enableQuickReplies && !!quickReplies.length) && h('div',{className:'qa-quick qa-quick-row'},
              quickReplies.map((q,i)=>h('button',{className:'qa-chip-btn',key:q.label+'|'+i,onClick:()=>handleQuickReplyAsAdmin(q.text),title:`Reply: ${q.text}`},q.label))
            ),
            h('div',{className:'qa-chat-input'},
              h('input',{type:'text',value:input,placeholder:'Type your message…',onChange:e=>setInput(e.target.value),onKeyDown:e=>{ if(e.key==='Enter') sendMessageText(); }}),
              h('button',{onClick:()=>sendMessageText()},'Send')
            ),
            !!error && h('div',{className:'qa-chat-error qa-error'}, error)
          ),

          (!isUserLoggedIn && tab==='book') && h('div',{className:'qa-book'},
            calendlyUrl ? h('iframe',{src:calendlyUrl, className:'calendly-inline-widget', title:'Book with Farhat Lectures'}) : h('div',{className:'qa-card'}, 'Booking is not configured yet.')
          )
        ),

        h('div',{className:'qa-nav'},
          h('button',{className:'qa-tab '+(tab==='home'?'active':''),onClick:goHome}, h(IconHome), h('span',null,'Home')),
          h('button',{className:'qa-tab '+(tab==='messages'?'active':''),onClick:goMessages}, h(IconChat), h('span',null,'Messages')),
          (!isUserLoggedIn) && h('button',{className:'qa-tab '+(tab==='book'?'active':''),onClick:goBooking}, h(IconCalendar), h('span',null,'Book'))
        )
      )
    );
  }

  function Boot() {
    const [cfg, setCfg] = useState(null);
    useEffect(() => { fetchPublicConfigWithMerge().then(setCfg); }, []);
    if (!cfg || cfg.widgetEnabled === false) return null;
    return h(GlobalWidget, { cfg });
  }

  document.addEventListener('DOMContentLoaded', () => {
    const mount = document.getElementById('qa-global-root');
    if (mount) render(h(Boot), mount);
  });
})(window.wp);
